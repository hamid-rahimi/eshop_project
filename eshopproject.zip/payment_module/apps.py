from django.apps import AppConfig


class PaymentModuleConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'payment_module'
