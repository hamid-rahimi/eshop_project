
SANDBOX = True
MERCHANT_ID = "ZAQ12WSXCDE34RFVBGT56YHNMJU78IKLO90P"

sandbox = 0
ZP_API_REQUEST = f"https://{sandbox}.zarinpal.com/pg/rest/WebGate/PaymentRequest.json"
ZP_API_VERIFY = f"https://{sandbox}.zarinpal.com/pg/rest/WebGate/PaymentVerification.json"
ZP_API_STARTPAY = f"https://{sandbox}.zarinpal.com/pg/StartPay/"

# Important: need to edit for realy server.
CallbackURL = 'http://127.0.0.1:8000/payment/verify/'